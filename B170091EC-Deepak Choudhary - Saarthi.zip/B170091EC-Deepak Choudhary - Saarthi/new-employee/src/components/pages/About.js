import React from "react";

const About = () => {
  return (
    <div className="container">
      <div className="py-4">
        <h1>Deepak Choudhary</h1>
        <p className="lead">
        Myself Deepak Choudhary, B.tech Final Year Undergraduate, Electronics and Communication Engineering, National Institute of Technology Sikkim.
I am Lead Coordinator of Training and Placement Cell NIT Sikkim.
I am looking for opportunities to gain confidence and experience using my potential in the Frontend  Development to further improve my skills in Recat js and express my innovative creative skills for self and company growth.
        </p>

       
      </div>
    </div>
  );
};

export default About;
